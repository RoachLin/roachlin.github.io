# 函数

def greet(user):  # 形参
    print('Hello, ' + user)


greet('lin')  # 实参

# 位置实参：实参的顺序与形参的顺序一一对应

# 关键字实参，实参顺序与形参顺序不必对应
greet(user='roach')


# 可以给形参指定默认值，若有实参则使用实参，若无实参则使用形参的默认值
# 使用默认值时，在形参列表中要先列出没有默认值的形参，这样才能正确解读位置实参


def repeat(user):
    return user


print(repeat('lin'))


# 可选实参
def get_name(first, last, middle=''):
    if middle:
        name = first + ' ' + middle + ' ' + last
    else:
        name = first + ' ' + last
    return name


print('roach', 'lin')
print('roach', 'qcym', 'lin')


# 禁止函数修改列表
# function_name(list_name[:])传递的是list_name的副本

# 传递任意数量的实参
def make_pizza(*topping):  # 星号*的作用是创建空元组，并将接收到的任意数量的实参都封装到这个元组中
    print(topping)


make_pizza('pepper')
make_pizza('mushroom', 'pepper', 'cheese')


# 使用任意数量的关键字实参
# 两个星号**的作用是创建空字典，并将接收到的所有键值对都封装到这个字典中
def build_profile(first, last, **user_info):
    profile = {'first_name': first, 'last_name': last}
    for key, value in user_info.items():
        profile[key] = value
    return profile


user_profile = build_profile('albert', 'einstein', location='princeton', field='physics')
print(user_profile)

# 模块（扩展名为.py的文件）

# 需要指定module_name.function_name()
import time

start = time.perf_counter()
print(sum(range(10000000)))
end = time.perf_counter()
print((end - start), "s")

# 只要指定function_name()即可
from math import sqrt, pi

print(pi)
print(sqrt(16))

# 使用as指定别名
# 给函数指定别名：from module_name import function_name as fn
# 给模块指定别名：import module_name as mn

# 导入模块中的所有函数
# 注意，最好不要这样做，因为有可能会有同名函数
# from module_name import *
