# 基础

# title()把字符串中所有单词的首字母转为大写
# istitle()检查字符串中所有单词的首字母是否为大写，且其他字母为小写
name = "roach lin"
print(name)
print(name.istitle())
name = name.title()
print(name)
print(name.istitle())
# 注意，非字母后的第一个字母将转为大写字母
# 该算法使用一种简单的与语言无关的定义，将连续的字母组合视为单词
txt = "hello b2b2b2 and 3g3g3g"
print(txt.title())
# upper()把字符串中所有小写字母转为大写
# isupper()检查字符串中所有字母是否为大写
name = name.upper()
print(name)
print(name.isupper())
# lower()把字符串中所有大写字母转为小写
# islower()检查字符串中所有字母是否为小写
name = name.lower()
print(name)
print(name.islower())

# 字符串拼接
print("roach" + " " + "lin")

# 输出制表符（tab）
print("python\tpython")
# 输出换行符
print("python\npython")

# strip()移除字符串头尾指定的字符（默认为空格）
# lstrip()只移除字符串头处，rstrip()只移除字符串尾处
# 注意，该方法只能删除开头或结尾的字符，不能删除中间的字符
print('   spacious   '.strip())
# 把参数看作一个列表，从头/尾开始逐一删除符合列表的字符，直到遇到一个不在列表中的字符为止
print('www.example.com'.strip('cmowz.'))

# 乘方
print(10 ** 6)

# str()转为字符串

# 单行注释
'''
多行注释1
多行注释2
'''
"""
多行注释3
多行注释4
"""

# Python之禅
import this
