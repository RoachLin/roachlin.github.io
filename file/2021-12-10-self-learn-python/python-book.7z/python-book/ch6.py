# 字典（键值对）
# Python不关心键值对的添加顺序，而只关心键和值之间的关联关系

# 创建空字典
alien_1 = {}
# 定义一个字典
alien_0 = {'color': 'green', 'points': 5}
# 访问字典中的值
print(alien_0['color'])
# 添加键值对
alien_0['x_position'] = 0
alien_0['y_position'] = 25
print(alien_0)
# 修改字典中的值
alien_0['y_position'] = 100
print(alien_0)
# 删除键值对
del alien_0['y_position']
print(alien_0)

# 遍历字典
# 遍历所有键值对
user_0 = {
    'username': 'qcym',
    'first': 'roach',
    'last': 'lin',
}
for key, value in user_0.items():
    print('\nkey: ' + key)
    print('value: ' + value)
print(user_0.items())  # items()以列表返回可遍历的(键,值)元组数组

# 遍历所有键
for key in user_0.keys():
    print(key)
# 遍历字典时会默认遍历所有键
for key in user_0:
    print(key)
# 可以用sorted()对键进行排序
for key in sorted(user_0.keys()):
    print(key)

# 遍历所有值
for value in user_0.values():
    print(value)
# 使用集合set()剔除重复项，set类似于列表，但每个元素必须是独一无二的
favorite_languages = {
    'jen': 'python',
    'sarah': 'c',
    'edward': 'ruby',
    'phil': 'python',
}
for language in set(favorite_languages.values()):
    print(language)

# 嵌套（将字典存储在列表中，将列表/字典作为值存储在字典中）
