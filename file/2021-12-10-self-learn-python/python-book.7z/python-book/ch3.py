# 列表
# 可以把任何东西放入列表中，列表元素之间可以没有任何关系

# 查
net = ['google', 'baidu', 'tencent', 'netease']
print(net)
print(net[0])
# 索引为-1返回最后一个元素，索引为-2返回倒数第二个元素，依此类推，在不知道列表长度时很有用
print(net[-1])

# 改
net[1] = 'riot'
print(net)

# 增
# 使用append()在列表末尾添加元素
net.append('CDPR')
print(net)
# 使用insert()在列表中插入元素
net.insert(1, 'bilibili')  # 尤其小心索引位置
print(net)

# 删
# 使用del删除元素
del net[4]
print(net)
# 使用pop()删除元素并存到新变量中，参数为空则默认删除最后一个
other1 = net.pop()
print(net)
print(other1)
other2 = net.pop(1)
print(net)
print(other2)
# 使用remove()根据值删除元素
# 注意，remove()只移除列表中某个值的第一个匹配项
net.remove('tencent')
print(net)

# 排序
# 使用sort()对列表进行永久性排序
net = ['google', 'baidu', 'tencent', 'netease', 'bilibili', 'acfun', 'riot']
net.sort()
print(net)
# 参数reverse为空默认是按字母顺序排列，反序排列要指定reverse为True
net = ['google', 'baidu', 'tencent', 'netease', 'bilibili', 'acfun', 'riot']
net.sort(reverse=True)
print(net)


# 参数key指定一个函数，表示按列表元素中的哪一个部分进行排列
def second(elem):
    return elem[1]


tmp = [(5, 2), (6, 4), (7, 1), (8, 3)]
tmp.sort(key=second)
print(tmp)

# key还可以是匿名函数
'''
python使用lambda来创建匿名函数。
    lambda只是一个表达式，函数体比def简单很多。
    lambda的主体是一个表达式，而不是一个代码块。仅仅能在lambda表达式中封装有限的逻辑进去。
    lambda函数拥有自己的命名空间，且不能访问自有参数列表之外或全局命名空间里的参数。
    虽然lambda函数看起来只能写一行，却不等同于C或C++的内联函数，后者的目的是调用小函数时不占用栈内存从而增加运行效率。
lambda函数的语法只包含一个语句：lambda [arg1 [,arg2,.....argn]]:expression
例子如下：
sum = lambda arg1, arg2: arg1 + arg2
print(sum(10, 20))
'''
example_list = [5, 0, 6, 1, 2, 7, 3, 4]
example_list.sort(key=lambda x: x * -1)
print(example_list)

# 使用sorted()对列表进行临时排序
# 这会让列表按特定顺序显示，但不会改变列表的原始顺序
net = ['google', 'baidu', 'tencent', 'netease', 'bilibili', 'acfun', 'riot']
print(sorted(net))
print(net)
# sorted()同样有参数reverse和key，用法与上面完全相同

# 使用reverse()反转列表的顺序
# 注意，reverse()不是指按与字母顺序相反的顺序进行排列，而是单纯地反转列表顺序，无论列表是否有序
# reverse()永久性地修改了列表的排列顺序，但可再次使用reverse()恢复到原来的状态
net.reverse()
print(net)

# 确定列表的长度
print(len(net))
