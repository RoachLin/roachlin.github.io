# if语句
age1 = 20
age2 = 22
if age1 >= 18 and age2 <= 25:  # or类似
    print(age1 + age2)

nets = ['google', 'bilibili', 'acfun', 'riot']
if 'google' in nets:
    print('yes')
if 'baidu' not in nets:
    print('not in')

age = 12
if age < 4:
    price = 0
elif age < 18:
    price = 5
elif age < 65:
    price = 10
elif age >= 65:  # 最后的else不是必要的
    price = 5

# 当if+列表名时，若列表为空则返回false，否则返回true
requested = []
if requested:
    print('not empty')
