# 操作列表（循环）
nets = ['google', 'bilibili', 'acfun', 'riot']
for net in nets:
    print(net)
    # break
    # continue

# 若for循环正常结束（有continue也可），则运行else语句
# 若for循环被break打断，则不运行else语句
sites = ["Baidu", "Google", "Runoob", "Taobao"]
for site in sites:
    if site == "Runoob":
        print("菜鸟教程!")
        break
    print("循环数据 " + site)
else:
    print("没有循环数据!")
print("完成循环!")

# 函数range()
for value in range(5):  # 默认从0开始
    print(value)

for value in range(1, 6):  # 可以指定区间的值
    print(value)

for value in range(1, 10, 2):  # 可以指定步长
    print(value)

for value in range(-10, -100, -10):  # 区间从大到小、步长为负数也可
    print(value)

# 使用range()创建列表
numbers = list(range(10))
print(numbers)

# 结合range()和len()函数以遍历列表
nets = ['google', 'bilibili', 'acfun', 'riot']
for net in range(len(nets)):
    print(net, nets[net])

# 列表解析
squares = [value ** 2 for value in range(1, 11)]
print(squares)

# 对数字列表执行简单的统计计算
digits = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
print(min(digits))  # 最小值
print(max(digits))  # 最大值
print(sum(digits))  # 求和

# pass是空语句，不做任何事情，一般用作占位语句，是为了保持程序结构的完整性。

# 使用列表的一部分（切片）
nets = ['google', 'bilibili', 'acfun', 'riot', 'cygames', 'can-dao']
print(nets[1:4])  # 生成子集
print(nets[:4])  # 若没有指定起始索引，则自动从列表开头开始
print(nets[1:])  # 若没有指定终止索引，则一直到列表末尾为止
print(nets[1:5:2])  # 也可指定步长
print(nets[-3:])  # 负数（代表从列表末尾开始计算距离）同样适用

# 复制列表
nets1 = ['google', 'bilibili', 'acfun']
nets2 = nets1  # 这是不行的，实际上nets1和nets2指向同一个列表
nets1.append('riot')
nets2.append('cygames')
print(nets1)
print(nets2)

nets1 = ['google', 'bilibili', 'acfun']
nets3 = nets1[:]
nets1.append('riot')
nets3.append('cygames')
print(nets1)
print(nets3)

# 列表是可以修改的，而不可修改的列表称为元组
nets = ('google', 'bilibili', 'acfun')
print(nets)
# 元组的元素不能修改，但可以对元组变量重新赋值
nets = ('riot', 'cygames')
print(nets)
