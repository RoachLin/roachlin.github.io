# 类（面向对象编程）
# 实例化：基于类创建对象

# 创建类
class Dog:
    def __init__(self, name, age):  # 构造函数，初始化属性name和age
        self.name = name
        self.age = age

    def sit(self):  # 蹲下
        print(self.name + ' is sitting')

    def roll_over(self):  # 打滚
        print(self.name + ' rolled over')


# 根据类创建实例
my_dog = Dog('willie', 6)
# 访问属性
print("my dog's name is " + my_dog.name)
print('my dog is ' + str(my_dog.age) + ' years old')
# 调用方法
my_dog.sit()
my_dog.roll_over()


# 使用类和实例
# Car类
class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.odometer = 0
        # 给属性指定默认值
        # 类中的每个属性都必须有初始值，要么在创建实例时提供，要么在构造函数中设置默认值

    def description(self):
        long_name = str(self.year) + ' ' + self.make + ' ' + self.model
        return long_name

    def read_odometer(self):
        print('this car has ' + str(self.odometer) + ' miles on it')

    def update_odometer(self, mileage):
        if mileage >= self.odometer:  # 里程表不能往回拨
            self.odometer = mileage
        else:
            print('can not roll back')

    def increase_odometer(self, miles):
        if miles >= 0:  # 里程表不能往回拨
            self.odometer += miles
        else:
            print('can not roll back')

    def fill_gas_tank(self):
        pass


my_new_car = Car('audi', 'a4', 2016)
print(my_new_car.description())
my_new_car.read_odometer()

# 修改属性的值
# 直接修改属性的值
my_new_car.odometer = 23
my_new_car.read_odometer()
# 通过方法修改属性的值
my_new_car.update_odometer(25)
my_new_car.read_odometer()
my_new_car.update_odometer(20)
my_new_car.read_odometer()
# 通过方法对属性的值进行递增
my_new_car.increase_odometer(100)
my_new_car.read_odometer()
my_new_car.increase_odometer(-100)
my_new_car.read_odometer()


# 继承
# 子类继承了父类的所有属性和方法，同时还可以定义自己的属性和方法
# 子类的方法__init__()
class ElectricCar(Car):  # 指定父类Car
    def __init__(self, make, model, year):
        super().__init__(make, model, year)  # super()调用父类（超类superclass）的方法
        self.battery_size = 70  # 给子类定义新属性

    def read_battery(self):  # 给子类定义新方法
        print('this car has a ' + str(self.battery_size) + '-kWh battery')

    def fill_gas_tank(self):  # 重写父类的方法
        print("this car doesn't need a gas tank")


my_tesla = ElectricCar('tesla', 'model s', 2016)
print(my_tesla.description())
my_tesla.read_battery()
my_tesla.fill_gas_tank()

# 导入类
# 从一个模块中导入多个类：from module_name import class_name1, class_name2, ......
# 导入整个模块：import module_name（使用时要指定module_name.class_name()）
# 导入模块中所有类：from module_name import *（尽量不要用）
# 在一个模块中导入另一个模块：from module_name import class_name

# Python 标准库
# 哈哈，Python3.6后字典有序了，不需要from collections import OrderedDict了
