# 数据可视化
import matplotlib.pyplot as plt

squares = [1, 4, 9, 16, 25]
plt.plot(squares)  # plot()绘制图形
plt.show()  # show()打开matplotlib查看器，并显示绘制的图形


