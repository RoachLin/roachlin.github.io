# Car类
class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.odometer = 0
        # 给属性指定默认值
        # 类中的每个属性都必须有初始值，要么在创建实例时提供，要么在构造函数中设置默认值

    def description(self):
        long_name = str(self.year) + ' ' + self.make + ' ' + self.model
        return long_name

    def read_odometer(self):
        print('this car has ' + str(self.odometer) + ' miles on it')

    def update_odometer(self, mileage):
        if mileage >= self.odometer:  # 里程表不能往回拨
            self.odometer = mileage
        else:
            print('can not roll back')

    def increase_odometer(self, miles):
        if miles >= 0:  # 里程表不能往回拨
            self.odometer += miles
        else:
            print('can not roll back')

    def fill_gas_tank(self):
        pass


# 将实例用作属性
# 在不断给ElectricCar类添加细节时，其中可能会包含很多专门针对汽车电瓶的属性和方法，
# 所以我们可以将这些属性和方法提取出来，放到另一个名为Battery的类中，
# 并将一个Battery实例用作ElectricCar类的一个属性
class Battery:
    def __init__(self, battery_size=70):
        self.battery_size = battery_size

    def read_battery(self):
        print('this car has a ' + str(self.battery_size) + '-kWh battery')

    def get_range(self):
        drive_range = 0

        if self.battery_size == 70:
            drive_range = 240
        elif self.battery_size == 85:
            drive_range = 270

        print('this car can go approximately ' + str(drive_range) + ' miles on a full charge')


class ElectricCar(Car):  # 指定父类Car
    def __init__(self, make, model, year):
        super().__init__(make, model, year)  # super()调用父类（超类superclass）的方法
        self.battery = Battery()


my_tesla = ElectricCar('tesla', 'model s', 2016)
print(my_tesla.description())
my_tesla.battery.read_battery()
my_tesla.battery.get_range()
