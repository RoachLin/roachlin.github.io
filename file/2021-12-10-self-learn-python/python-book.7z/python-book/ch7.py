# 输入和while循环

# input()获取的输入是字符串，若要进行数值运算则要先用int()
message = input('Please input something: ')
print(message)

# 求模运算符（%）返回的是两数相除的余数

num = 1
while num <= 5:
    print(num)
    num += 1

# 设置标志变量flag
